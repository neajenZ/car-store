import { Car } from "../../graphql/generated"



export type IProps = {
    car: Car
}