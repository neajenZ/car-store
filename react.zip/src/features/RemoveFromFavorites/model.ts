


export type IProps = {
    carId: number
}