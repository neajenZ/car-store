import { Car } from "../../graphql/generated"




export type IInitialState = {
    favorites: Car[]
}