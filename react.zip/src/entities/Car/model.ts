import { Car } from "../../graphql/generated"

export type IProps = {
    data: Car
}